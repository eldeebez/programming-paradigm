object LazyListOperations {

  // Function to transform elements of a lazy list using modulo
  def doModulo(lazyList: LazyList[Int], moduloValue: Int): LazyList[Int] = {
    lazyList.map(_ % moduloValue)
  }

  def main(args: Array[String]): Unit = {
    // Example usage
    val inputLazyList = LazyList(1, 2, 3, 4, 5)
    val moduloValue = 3

    // Apply doModulo function
    val resultLazyList = doModulo(inputLazyList, moduloValue)

    // Print the original and transformed lazy lists
    println(s"Original LazyList: ${inputLazyList.toList}")
    println(s"Transformed LazyList (modulo $moduloValue): ${resultLazyList.toList}")
  }
}
