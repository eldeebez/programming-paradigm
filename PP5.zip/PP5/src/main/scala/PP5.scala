object Main extends App {
  // Task 1: Define a function to repeat each element of a lazy list k times
  def lrepeat[A](k: Int)(lxs: LazyList[A]): LazyList[A] = {
    // Use flatMap to apply the function that repeats each element k times
    lxs.flatMap(x => LazyList.fill(k)(x))
  }

  // Task 2: Define a function to generate the Fibonacci Sequence in a lazy way
  def fib: LazyList[Int] = {
    // Define a helper function using recursion to generate Fibonacci Sequence an applying the formula for it
    def fibHelper(a: Int, b: Int): LazyList[Int] = a #:: fibHelper(b, a + b)

    // Start the sequence with 0 and 1
    fibHelper(0, 1)
  }

  // Task 3: Define a function to generate a lazy binary tree with limited depth
  trait lBT[+A]
  case object LEmpty extends lBT[Nothing]
  case class LNode[+A](elem: A, left: () => lBT[A], right: () => lBT[A]) extends lBT[A]

  //the input is (1, 2, 3) to be repeated twice
  //the output for Task1: Repeated List -> List(1, 1, 2, 2, 3, 3) A Function to generate a lazy binary tree with limited depth
  def generateTreeWithDepth(n: Int, depth: Int): lBT[Int] = {
    if (depth <= 0) LEmpty
    else LNode(n, () => generateTreeWithDepth(2 * n, depth - 1), () => generateTreeWithDepth(2 * n + 1, depth - 1))
  }

  // Function to collect elements of a lazy binary tree into a list to be shown later as a list for the user
  def collectTreeElements[A](tree: lBT[A]): List[A] = tree match {
    case LEmpty => Nil
    case LNode(elem, left, right) => elem :: (collectTreeElements(left()) ++ collectTreeElements(right()))
  }

  // Example usage:
  // Task 1: the example usage for the lazy list repeating the inputted integers twice
  println("the input is (1, 2, 3) to be repeated twice")
  val repeatedList = lrepeat(2)(LazyList(1, 2, 3))
  println("the output for Task1: Repeated List -> " + repeatedList.toList)

  // Task 2: the example usage for the fibonacci sequence with a limit 8 integers
  println("the input is (0, 1) to start with and the process is till the 8th term ")
  val fibonacciSequence = fib.take(8)
  println("the output for Task2: Fibonacci Sequence -> " + fibonacciSequence.toList)

  // Task 3: the example usage for the limited binary tree depth is 4 and starting from the integer 1
  println("the input is: 1 as a starting integer till the 8th depth of the binary tree ")
  val treeLimitedDepth = generateTreeWithDepth(1, 4) // Limiting depth to 3 for example
  val treeElements = collectTreeElements(treeLimitedDepth)
  println("the output for Task3: Limited Depth Lazy Binary Tree with Root 1 -> " + treeElements)
}
