object PP3 {

  // Task 1: Sum the values in a list using tail recursion
  def sumList(list: List[Int]): Int = {
    def sumTailRec(list: List[Int], acc: Int): Int = {
      list match {
        case Nil => acc // Base case: when the list is empty, return the accumulator
        case head :: tail => sumTailRec(tail, acc + head)
        // Recursively add the head to the accumulator and process the tail
      }
    }

    sumTailRec(list, 0) // Start the tail-recursive function with an initial accumulator of 0
  }

  // Task 2a: Reverse a List using regular recursion
  def reverseListRecursive[A](list: List[A]): List[A] = {
    list match {
      case Nil => Nil // Base case: an empty list remains empty
      case head :: tail => reverseListRecursive(tail) :+ head
      // Recursively reverse the tail of the list and append the head to it
    }
  }

  // Task 2b: Reverse a List using tail recursion
  def reverseListTailRecursive[A](list: List[A]): List[A] = {
    def reverseHelper(acc: List[A], remaining: List[A]): List[A] = {
      remaining match {
        case Nil => acc // When there are no more elements in the remaining list, return the accumulator
        case head :: tail => reverseHelper(head :: acc, tail)
        // Reverse by adding the head to the accumulator and processing the tail
      }
    }

    reverseHelper(Nil, list)
  }

  // Task 3: Merge two lists with alternating elements
  def mergeListsAlternate[A](list1: List[A], list2: List[A]): List[A] = {
    def mergeListsHelper(result: List[A], remaining1: List[A], remaining2: List[A]): List[A] = {
      (remaining1, remaining2) match {
        case (Nil, Nil) => result // When both lists are empty, return the result
        case (h1 :: t1, h2 :: t2) => mergeListsHelper(result :+ h1 :+ h2, t1, t2)
        // Combine the heads of both lists and recursively merge the tails
        case (h1 :: t1, Nil) => mergeListsHelper(result :+ h1, t1, Nil)
        // If the second list is empty, add the remaining elements of the first list
        case (Nil, h2 :: t2) => mergeListsHelper(result :+ h2, Nil, t2)
        // If the first list is empty, add the remaining elements of the second list
      }
    }

    mergeListsHelper(Nil, list1, list2)
  }

  // Task 4: Find the n-th Fibonacci number using tail recursion
  def fibonacciNth(n: Int): Int = {
    def fibonacciTailRec(current: Int, prev: Int, n: Int): Int = {
      if (n <= 0) current // Return the current value when n is 0 or negative
      else fibonacciTailRec(current + prev, current, n - 1)
      // Calculate the next Fibonacci number by adding current and previous values
    }

    if (n <= 0) 0 // Handle the case where n is 0 or negative
    else if (n == 1) 1 // Handle the case where n is 1
    else fibonacciTailRec(1, 0, n - 2)
    // Start with initial values 1 (current) and 0 (previous) for Fibonacci calculation
  }

  // Task 5: Split a list into odd and even numbers
  def splitOddEvenNumbers(list: List[Int]): (List[Int], List[Int]) = {
    def splitHelper(remaining: List[Int], odd: List[Int], even: List[Int]): (List[Int], List[Int]) = {
      remaining match {
        case Nil => (odd.reverse, even.reverse) // Reverse the lists to maintain the original order
        case head :: tail if head % 2 == 0 => splitHelper(tail, odd, head :: even)
        // If the head is even, add it to the even list
        case head :: tail => splitHelper(tail, head :: odd, even)
        // If the head is odd, add it to the odd list
      }
    }

    splitHelper(list, Nil, Nil)
  }

  // Task 6: Check if a list is correctly sorted using tail recursion
  def isSorted(list: List[Int]): Boolean = {
    def checkSorted(remaining: List[Int]): Boolean = {
      remaining match {
        case Nil => true // An empty list is considered sorted
        case head1 :: (head2 :: _ as tail) if head1 > head2 => false
        // If there is an out-of-order element, the list is not sorted
        case _ :: tail => checkSorted(tail)
        // Recursively check the rest of the list
      }
    }

    checkSorted(list)
  }

  // Task 7: Define the replaceNth function to replace the n-th element of the list
  def replaceNth[A](xs: List[A], n: Int, x: A): List[A] = {
    def replaceHelper(remaining: List[A], index: Int, acc: List[A]): List[A] = {
      (remaining, index) match {
        case (Nil, _) => acc.reverse ++ xs.drop(acc.length)
        // When the end of the list is reached, append the remaining elements from xs
        case (head :: tail, 0) => replaceHelper(tail, -1, x :: acc)
        // Replace the n-th element with x
        case (head :: tail, i) => replaceHelper(tail, i - 1, head :: acc)
        // Continue traversing the list, maintaining the index and accumulator
      }
    }

    if (n >= 0) replaceHelper(xs, n, Nil)
    else xs // Return the original list if n is negative
  }

  // Task 8: Convert pressure units using curried representation
  def convertPressure(atm: Double)(unit: String): Double = {
    unit match {
      case "PSI" => atm * 14.6956
      case "bar" => atm * 1.01325
      case "torr" => atm * 760.0
      case _ => 0.0 // Handle unknown units gracefully
    }
  }

  def main(args: Array[String]): Unit = {
    // Test the functions
    val list = List(1, 2, 3, 4, 5, 6)
    val n = 7

    println("Sum of List: " + sumList(list))
    println("Reversed List (Regular Recursion): " + reverseListRecursive(list))
    println("Reversed List (Tail Recursion): " + reverseListTailRecursive(list))
    println("Merged List (Alternating): " + mergeListsAlternate(List(1, 2, 3), List(4, 5, 6)))
    println(s"$n-th Fibonacci number: " + fibonacciNth(n))
    val (oddNumbers, evenNumbers) = splitOddEvenNumbers(list)
    println("Odd Numbers: " + oddNumbers)
    println("Even Numbers: " + evenNumbers)
    println("Is the list sorted? " + isSorted(list))
    println("Replace $n-th element: " + replaceNth(list, n - 1, 0))
    println("Pressure Conversion: " + convertPressure(1.0)("bar"))
  }
}
