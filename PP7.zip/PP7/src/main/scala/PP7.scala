object ScalaTasks extends App {

  // Task 1: Sum and Product Function
  def sumProd(s: Int, e: Int): (Int, Int) = {
    // Generate a list of integers from s (inclusive) to e (exclusive)
    val numbers = (s until e).toList

    // Calculate the sum and product of the generated numbers
    val sum = numbers.sum
    val product = numbers.product

    // Return a tuple containing the sum and product
    (sum, product)
  }

  // Task 2: Perfect Number Function
  def isPerfect(n: Int): Boolean = {
    // Find divisors of n by filtering numbers from 1 to n-1 that evenly divide n
    val divisors = (1 until n).filter(n % _ == 0)

    // Check if the sum of divisors equals n, indicating a perfect number
    divisors.sum == n
  }

  // Task 3: Insert Function
  def insert(list: List[Int], element: Int, position: Int): List[Int] = {
    // Ensure the position is within a valid range
    val index = if (position < 0) 0 else if (position > list.length) list.length else position

    // Split the original list at the determined index
    val (before, after) = list.splitAt(index)

    // Concatenate the elements before the index, the new element, and elements after the index
    before ++ List(element) ++ after
  }

  // Example usage for all three tasks
  val (sumResult, prodResult) = sumProd(1, 6)
  println(s"Task 1 - Sum: $sumResult, Product: $prodResult")

  val numberToCheck = 27
  val isPerfectNumber = isPerfect(numberToCheck)
  println(s"Task 2 - $numberToCheck is perfect: $isPerfectNumber")

  val myList = List(2, 4, 8, 16, 32, 64)
  val newElement = 88
  val newPosition = 3
  val newList = insert(myList, newElement, newPosition)
  println(s"Task 3: - Original List: $myList")
  println(s"        - New List: $newList")
}
