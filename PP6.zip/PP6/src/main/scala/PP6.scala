object DateExample {

  // Task 1: Define a class for a simplified date in the year
  class DayInYear(private var _month: Int, private var _day: Int) {
    private val DaysInMonth = 30

    // Adjust the values in the constructor
    if (_month < 1) _month = 1
    else if (_month > 12) _month = 12

    if (_day < 1) _day = 1
    else if (_day > DaysInMonth) _day = DaysInMonth

    // Getter methods for month and day
    def month: Int = _month
    def day: Int = _day

    // Setter methods that throw exceptions for invalid values
    def month_=(newMonth: Int): Unit = {
      if (newMonth < 1 || newMonth > 12) throw new IllegalArgumentException("Invalid month")
      _month = newMonth
    }

    def day_=(newDay: Int): Unit = {
      if (newDay < 1 || newDay > DaysInMonth) throw new IllegalArgumentException("Invalid day")
      _day = newDay
    }

    // Method to move the date forward cyclically
    def shift(numberDays: Int): Unit = {
      val totalDays = _month * DaysInMonth + _day + numberDays
      _month = (totalDays - 1) / DaysInMonth % 12 + 1
      _day = (totalDays - 1) % DaysInMonth + 1
    }
  }

  // Companion object for Task 1: Provide a factory method to create instances without using 'new'
  object DayInYear {
    def apply(month: Int, day: Int): DayInYear = new DayInYear(month, day)
  }

  // Task 2: Define a class for a simplified date of the year with days from the beginning
  class DayInYearFromStart(private var _dayFromStart: Int) {
    private val DaysInYear = 12 * 30

    // Adjust the value in the constructor
    if (_dayFromStart < 1) _dayFromStart = 1
    else if (_dayFromStart > DaysInYear) _dayFromStart = DaysInYear

    // Getter method for days from the beginning
    def dayFromStart: Int = _dayFromStart

    // Setter method that throws an exception for an invalid value
    def dayFromStart_=(newDayFromStart: Int): Unit = {
      if (newDayFromStart < 1 || newDayFromStart > DaysInYear)
        throw new IllegalArgumentException("Invalid day from start")
      _dayFromStart = newDayFromStart
    }
  }

  // Companion object for Task 2: Provide a factory method to create instances without using 'new'
  object DayInYearFromStart {
    def apply(dayFromStart: Int): DayInYearFromStart = new DayInYearFromStart(dayFromStart)
  }

  // Task 3: Define the Student class with unmodifiable fields (index, name) and modifiable fields (surname, city, income)
  class Student(val index: Int, val name: String, var surname: String, var city: String = "", var income: Int = 0)

  // Companion object for Task 3: Provide overloaded factory methods for creating instances of the Student class
  object Student {
    def apply(index: Int, name: String, surname: String): Student =
      new Student(index, name, surname)

    def apply(index: Int, name: String, surname: String, city: String): Student =
      new Student(index, name, surname, city)

    def apply(index: Int, name: String, surname: String, city: String, income: Int): Student =
      new Student(index, name, surname, city, income)
  }

  // Main class with example usage
  def main(args: Array[String]): Unit = {
    // Example usage
    val date1 = DayInYear(5, 25)
    println(s"Date 1: Month ${date1.month}, Day ${date1.day}")

    val date2 = DayInYearFromStart(120)
    println(s"Date 2: Day from start ${date2.dayFromStart}")

    val student1 = Student(1, "John", "Doe")
    println(s"Student 1: ${student1.index}, ${student1.name}, ${student1.surname}, ${student1.city}, ${student1.income}")

    val student2 = Student(2, "Jane", "Smith", "New York")
    println(s"Student 2: ${student2.index}, ${student2.name}, ${student2.surname}, ${student2.city}, ${student2.income}")

    val student3 = Student(3, "Bob", "Johnson", "Los Angeles", 50000)
    println(s"Student 3: ${student3.index}, ${student3.name}, ${student3.surname}, ${student3.city}, ${student3.income}")
  }
}
