object ScalaTasks {

  // Task 1: Find Primes using Sieve of Eratosthenes
  def primesInRange(start: Int, end: Int): List[Int] = {
    // Step 1: Generate a list of potential primes using Sieve of Eratosthenes
    val isPrime = Array.fill(end + 1)(true)
    isPrime(0) = false
    isPrime(1) = false

    for (i <- 2 to Math.sqrt(end).toInt if isPrime(i))
      for (j <- i * i to end by i)
        isPrime(j) = false

    // Step 2: Filter out primes in the specified range
    (start to end).filter(isPrime).toList
  }

  // Task 2: Simple Calculator using ADT and Pattern Matching
  sealed trait CalculatorOp
  case class Add(a: Int, b: Int) extends CalculatorOp
  case class Negate(n: Int) extends CalculatorOp

  // Function to evaluate calculator operations using pattern matching
  def evaluate(op: CalculatorOp): Int = op match {
    case Add(a, b) => a + b
    case Negate(n) => -n
  }

  // Task 3: Bool ADT and Logic Functions
  sealed trait Bool
  case object True extends Bool
  case object False extends Bool

  // Logic functions using pattern matching
  def AND(a: Bool, b: Bool): Bool = (a, b) match {
    case (True, True) => True
    case _ => False
  }

  def OR(a: Bool, b: Bool): Bool = (a, b) match {
    case (True, _) | (_, True) => True
    case _ => False
  }

  def XOR(a: Bool, b: Bool): Bool = (a, b) match {
    case (True, False) | (False, True) => True
    case _ => False
  }

  def NAND(a: Bool, b: Bool): Bool = NOT(AND(a, b))

  def NOR(a: Bool, b: Bool): Bool = NOT(OR(a, b))

  def NOT(a: Bool): Bool = a match {
    case True => False
    case False => True
  }

  // Task 4: Pattern Matching for Type Information
  def printTypeInformation(value: Any): Unit = value match {
    case _: Int => println("It's an Integer.")
    case _: Double => println("It's a Double.")
    case _: String => println("It's a String.")
    case _: Bool => println("It's a Bool.")
    case _ => println("Unknown type.")
  }

  def main(args: Array[String]): Unit = {
    // Task 1: Find Primes
    val primesList = primesInRange(0, 200)
    println("Prime numbers between 0 and 200: " + primesList)

    // Task 2: Simple Calculator
    val result1 = evaluate(Add(7, 5))
    val result2 = evaluate(Negate(2))
    println(s"Calculator results: $result1, $result2")

    // Task 3: Bool ADT and Logic Functions
    val bool1 = True
    val bool2 = False
    println(s"AND: ${AND(bool1, bool2)}")
    println(s"OR: ${OR(bool1, bool2)}")
    println(s"XOR: ${XOR(bool1, bool2)}")
    println(s"NAND: ${NAND(bool1, bool2)}")
    println(s"NOR: ${NOR(bool1, bool2)}")

    // Task 4: Pattern Matching for Type Information
    val testValue: Any = "dzien dobry"
    printTypeInformation(testValue)

  }
}
