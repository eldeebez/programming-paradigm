object PowerCalculator {

  // Non-tailed recursion method for calculating power modulo
  def potegaNonTailed(base: Int, exponent: Int, modulo: Int): Int = {
    // Base case: if exponent is 0, return 1 (base^0 mod modulo)
    if (exponent == 0) {
      1 % modulo
    } else {
      // Recursively calculate halfPower
      val halfPower = potegaNonTailed(base, exponent / 2, modulo)

      // Calculate the result based on the binary exponentiation algorithm
      val result = if (exponent % 2 == 0) {
        (halfPower * halfPower) % modulo
      } else {
        (base * halfPower * halfPower) % modulo
      }

      // Ensure the result is non-negative by adding modulo and taking modulo again
      (result + modulo) % modulo
    }
  }

  // Tail recursion with binary exponentiation method for calculating power modulo
  def potegaTailBinary(base: Int, exponent: Int, modulo: Int): Int = {
    // Helper function for tail recursion with binary exponentiation
    def powWithBinary(base: Int, exponent: Int, accumulator: Int): Int = {
      // Base case: if exponent is 0, return the accumulator
      if (exponent == 0) {
        accumulator % modulo
      } else if (exponent % 2 == 0) {
        // If exponent is even, square the base and continue recursion
        powWithBinary((base.toLong * base.toLong % modulo).toInt, exponent / 2, accumulator)
      } else {
        // If exponent is odd, multiply the base with the accumulator, square the base, and continue recursion
        powWithBinary((base.toLong * base.toLong % modulo).toInt, exponent / 2, (accumulator.toLong * base.toLong % modulo).toInt)
      }
    }

    // Start the tail recursion with binary exponentiation
    powWithBinary(base, exponent, 1)
  }

  def main(args: Array[String]): Unit = {
    // Test values
    val base = 2
    val exponent = 10
    val modulo = 1000000007

    // Test non-tailed recursion
    val resultNonTailed = potegaNonTailed(base, exponent, modulo)
    println(s"The result (non-tailed recursion) of $base^$exponent mod $modulo is: $resultNonTailed")

    // Test tail recursion with binary exponentiation
    val resultTailBinary = potegaTailBinary(base, exponent, modulo)
    println(s"The result (tail recursion with binary exponentiation) of $base^$exponent mod $modulo is: $resultTailBinary")
  }
}
