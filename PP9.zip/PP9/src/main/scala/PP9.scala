import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{Future, Await}
import scala.concurrent.duration._

// Class representing the Bank with multiple accounts
class Bank(var accounts: Array[Int]) {
  // Method to simulate a money transfer between two accounts
  def transfer(from: Int, to: Int): Unit = {
    // Simulate a money transfer by subtracting 1 from the sender and adding 1 to the receiver
    accounts(from) -= 1
    accounts(to) += 1
  }

  // Method to calculate the total balance of all accounts in the bank
  def totalBalance: Int = accounts.sum
}

object Main extends App {
  // Constants for the problem
  val numAccounts = 100
  val initialBalance = 100
  val numTransfersPerThread = 1000

  // Create a Bank with 100 accounts, each having an initial balance of 100 PLN
  val bank = new Bank(Array.fill(numAccounts)(initialBalance))

  // Generate a deterministic sequence of transfers
  val transferSequence = for {
    _ <- 1 to numTransfersPerThread
    from = scala.util.Random.nextInt(numAccounts)
    to = (from + 1) % numAccounts // Ensure 'to' is the next account
  } yield (from, to)

  // Execute the transfers in a deterministic order
  transferSequence.foreach { case (from, to) =>
    bank.transfer(from, to)
  }

  // Print the final total balance of the bank
  println(s"Final total balance: ${bank.totalBalance}")
}
