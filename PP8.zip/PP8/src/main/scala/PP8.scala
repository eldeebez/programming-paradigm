object CombinedTasks extends App {

  // Task 1: CutOut Function
  def cutOut(a: Int, b: Int): List[Int] => List[Int] = {
    // Define a function that takes a list and extracts elements between positions a and b
    {
      case list =>
        list.zipWithIndex.collect {
          case (value, index) if index >= a && index <= b => value
        }
    }
  }

  // Task 2a: Split3Rec Function (Regular Recursion)
  def split3Rec[A]: List[A] => (List[A], List[A]) = {
    // Define a helper function for regular recursion
    def splitRecHelper(lst: List[A], acc1: List[A], acc2: List[A], turn: Boolean): (List[A], List[A]) = lst match {
      case Nil => (acc1.reverse, acc2.reverse)
      case head :: tail =>
        // Alternate between adding elements to acc1 and acc2
        if (turn) splitRecHelper(tail, head :: acc1, acc2, !turn)
        else splitRecHelper(tail, acc1, head :: acc2, !turn)
    }

    // Initial call with an empty accumulator and starting turn set to true
    list => splitRecHelper(list, Nil, Nil, true)
  }

  // Task 2b: Split3Tail Function (Tail Recursion)
  def split3Tail[A]: List[A] => (List[A], List[A]) = {
    // Define a helper function for tail recursion
    def splitTailHelper(lst: List[A], acc1: List[A], acc2: List[A], turn: Boolean): (List[A], List[A]) = lst match {
      case Nil => (acc1.reverse, acc2.reverse)
      case head :: tail =>
        // Alternate between adding elements to acc1 and acc2
        if (turn) splitTailHelper(tail, head :: acc1, acc2, !turn)
        else splitTailHelper(tail, acc1, head :: acc2, !turn)
    }

    // Initial call with an empty accumulator and starting turn set to true
    list => splitTailHelper(list, Nil, Nil, true)
  }

  // Example usage for all three tasks
  val cutOutt = cutOut(3, 9)
  val myList = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
  val result = cutOutt(myList)
  println(s"Task 1 - CutOut Result: $result")

  val (firstHalfRec, secondHalfRec) = split3Rec(myList)
  println(s"Task 2a using regular recursion - First Half: $firstHalfRec, Second Half: $secondHalfRec")

  val (firstHalfTail, secondHalfTail) = split3Tail(myList)
  println(s"Task 2b using tail recursion - First Half: $firstHalfTail, Second Half: $secondHalfTail")
}
